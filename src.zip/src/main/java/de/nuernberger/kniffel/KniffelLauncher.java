package de.nuernberger.kniffel;

public class KniffelLauncher {
    public static void main(String[] args) {
        KniffelApplication.main(args);
    }
}
